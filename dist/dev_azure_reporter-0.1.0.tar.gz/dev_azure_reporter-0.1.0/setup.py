# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['dev_azure_reporter']

package_data = \
{'': ['*']}

install_requires = \
['requests>=2.28.1,<3.0.0']

setup_kwargs = {
    'name': 'dev-azure-reporter',
    'version': '0.1.0',
    'description': 'A tool for reporting from GitHub Actions / GitLab CI/CD to Azure DevOps',
    'long_description': '# dats-dev_azure_reporter\nProof-of-Concept for reporting from GitHub Actions to dev.azure.com WorkItems.\n\nThis command-line tool allows for updating TaskItems at dev.azure.com from GitHub Actions or GilLab CI/CD via REST API calls. \n\n## Prerequisites:\n\n  You need a Personal Access Token (PAT). It can be obtained from dev.azure.com, top menu -> User settings -> Personal Access Tokens. \n  Token can be issued for up to a year and can be renewed; token does not need full access to organization and should be created with limited scopes (Scopes -> Custom defined, select "WorkItems Read & write" from the list of available scopes). The token should be stored in GitHub secrets and used from there.\n\n## Usage:\n  This tool can be used in two modes:\n  \n  1. Update a specific TaskItem via its id.\n      Parameters:\n        - -token - Personal Access Token\n        - -project_path - a path to organization and project at dev.azure.com; format: <organization/project>\n        - **-task_id** - A TaskItem id from dev.azure.com\n        - -field - A name of TaskItem metadata field to write to\n        - -value - A value to write to TaskItem metadata field\n        - -operation - Either "replace" to erase current field value or "add" to append to it\n      \n      Example:\n      ```\n        python dev_azure_reporter.py -token ewopro4r349id4kpdidaksjldas -project_path "digitalfoundation/data-at-scale" -task_id 3712 -field "System.Description" -value "Build was successful" -operation add\n      ```\n  2. Update a set of TaskItems that match the query: current repository/branch name must be present in a specified field of TaskItem.\n    \n      Parameters:\n        - -token - Personal Access Token\n        - -project_path - a path to organization and project at dev.azure.com; format: <organization/project>\n        - **-git_path** - a path to a repository and branch where the script is being called from; format: <repository/branch>\n        - **-filter_by** - a name of TaskItem metadata field where to look for git_path; only TaskItems that have git_path in this field will be updated\n        - **-task_limit** - a maximium count of TaskItems that can be updated by the script; protects from unintentional updating a large number of TaskItems by using a frequently-occurring string in git_path parameter\n        - -field - a name of a TaskItem metadata field to write to\n        - -value - a value to write to a TaskItem metadata field\n        - -operation - either "replace" to erase current TaskItem field value or "add" to append to it\n      \n      Example:\n        ```\n        python dev_azure_reporter.py -token ewopro4r349id4kpdidaksjldas -project_path "digitalfoundation/data-at-scale" -git_path "my_repo/this_branch" -filter_by "System.Description" -field "Custom.Securityarchitecturereviewnotes" -value "Security check completed" -op "replace".\n        ```\n        ',
    'author': 'Aleksandr Bogomolov',
    'author_email': 'aleksandr.bogomolov.ext@bayer.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
