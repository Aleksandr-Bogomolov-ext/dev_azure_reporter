import argparse

from .service import DevAzureReporter, TASKITEM_QUERY_LIMIT


parser = argparse.ArgumentParser()

parser.add_argument(
    "-token",
    required=True,
    help="""
    Personal Access Token (PAT) from dev.azure.com. Token lifespan cannot exceed a year, manual renewal is required.
""",
)
parser.add_argument(
    "-project",
    "-project_path",
    required=True,
    dest="project_path",
    help="""
    Organization/project path at dev.azure.com. Format: "<organization>/<project>".
""",
)
parser.add_argument(
    "-task_id",
    required=False,
    help="""
    Target task id. If specified, only a TaskItem with this id will be updated. 
    Cannot be used with <git_path> and <filter_by> parameters.
""",
)
parser.add_argument(
    "-git_path",
    required=False,
    help=f"""
    Current repository and branch name. Format: "<repository>#<branch>". 
    If specified, only TaskItems containing <git_path> in <filter_by> will be updated.
    If a number of matching TaskItems exceeds a limit ({TASKITEM_QUERY_LIMIT}), the script will fail.
    A limit can be specified via <task_limit> parameter. 
    Cannot be used with <task_id> parameter.
""",
)
parser.add_argument(
    "-filter_by",
    required=False,
    help="""
    If specified, only TaskItems containing <git_path> in <filter_by> field will be updated. 
    Cannot be used with <task_id> parameter.
""",
)
parser.add_argument(
    "-task_limit",
    required=False,
    default=TASKITEM_QUERY_LIMIT,
    help="""
    If specified, the parameter overrides the default limit of the number of TaskItems
    that can be updated by the script. This parameter can be used with <git_path> and <filter_by> parameters. 
    Cannot be used with <task_id> parameter.
""",
)
parser.add_argument(
    "-field_name",
    "-field",
    dest="field_name",
    required=True,
    help="""
    A name of a TaskItem field to write <field_value> to.
""",
)
parser.add_argument(
    "-field_value",
    "-value",
    "-val",
    dest="field_value",
    required=True,
    help="""
    A value for a field. Can contain unicode characters and html markup.
""",
)
parser.add_argument(
    "-operation",
    "-op",
    dest="operation",
    choices=["replace", "add"],
    default="replace",
    required=False,
    help="""
    An operation to perform on a field. 
    Allowed values: "replace", "add" (appends the field_value to the existing field). Default value is "replace".
""",
)

args = parser.parse_args()

reporter = DevAzureReporter(args.project_path, args.token, args.task_limit)

# depending on parameters, either update a single TaskItem by task_id or many TaskItems that match the search criterion
if args.task_id and (args.filter_by == args.git_path == None):
    try:
        task_id = reporter.report(
            args.task_id, args.field_name, args.field_value, args.operation
        )
        print(f"The task {task_id} was successfully updated")
    except Exception as e:
        print(e)
        exit(1)
elif (args.filter_by and args.git_path) and args.task_id is None:
    try:
        task_ids = reporter.report_batch(
            args.filter_by,
            args.git_path,
            args.field_name,
            args.field_value,
            args.operation,
        )
        print(f"The following tasks were successfully updated:",
              ", ".join([str(task_id) for task_id in task_ids]))
    except Exception as e:
        print(e)
        exit(1)
else:
    print(
        "Please either specify a single task via <task_id> or search criterion via <git_path> and <filter_by>."
    )
    exit(1)

exit(0)
