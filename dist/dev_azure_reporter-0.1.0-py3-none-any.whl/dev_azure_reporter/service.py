import requests
import json
from requests.auth import HTTPBasicAuth
from requests.exceptions import ConnectTimeout, HTTPError


BASE_WORKITEM_URL = "https://dev.azure.com/#PROJECT_PATH#/_apis/wit/workItems/"
BASE_QUERY_URL = "https://dev.azure.com/#PROJECT_PATH#/_apis/wit/wiql"

WORKITEM_API_VERSION = "7.1-preview"
QUERY_API_VERSION = "7.1-preview"

GIT_PATH_MIN_LENGTH = 10
TASKITEM_QUERY_LIMIT = 1


class DevAzureReporter:
    def __init__(
        self,
        dev_azure_org_project: str,
        token: str,
        taskitem_query_limit: int = TASKITEM_QUERY_LIMIT,
    ) -> None:

        self.dev_azure_org_project = dev_azure_org_project
        self.token = token
        self.workitem_url = BASE_WORKITEM_URL.replace(
            "#PROJECT_PATH#", self.dev_azure_org_project
        )
        self.query_url = BASE_QUERY_URL.replace(
            "#PROJECT_PATH#", self.dev_azure_org_project
        )
        self.taskitem_query_limit = taskitem_query_limit

    def _read_taskitem(self, task_id: int) -> dict:
        """
        This function reads all field values from the TaskItem.
        Accepts task_id (dev.azure.com TaskItem id).
        Returns fields dictionary.
        """

        url = f"{self.workitem_url}{task_id}"

        rslt = requests.get(
            url,
            headers={"Accept": "application/json"},
            auth=HTTPBasicAuth("", self.token),
            params={"api-version": WORKITEM_API_VERSION},
            timeout=10,
        )

        if rslt.status_code == 203:
            raise HTTPError("Token is not recognized")
        if rslt.status_code == 404:
            raise HTTPError(
                f"Organization or project is invalid: {self.dev_azure_org_project}")

        return rslt.json()["fields"]

    def _read_taskitem_value(self, task_id: int, field_name: str) -> dict:
        """
        This function reads an existing value from the TaskItem.
        Accepts task_id (dev.azure.com TaskItem id) and field_name.
        Returns a value of a field if the field exists or an empty string otherwise.
        """
        try:
            return self._read_taskitem(task_id)[field_name]
        except KeyError as e:
            return ""

    def _git_path_is_valid(self, git_path):
        """
        This function checks if git_path conforms to the following restrictions:
        - overall length is not less than 10 characters;
        - contains no spaces;
        - contains "#" symbol.

        The purpose of this check is a reduction of a possible false positives
        in _find_tasks - if git_path contains some generic string (or a single letter),
        _find_tasks will return TaskItems that were not intended to be modified by
        this script.

        Returns True if git_path is valid or False otherwise
        """

        if "#" not in git_path:
            return False
        if " " in git_path:
            return False
        if len(git_path) < GIT_PATH_MIN_LENGTH:
            return False

        return True

    def _find_tasks(self, query_field: str, git_path: str) -> list:
        """
        This function performs a search for TaskItems that contain git_path in their metadata field specified in query_field.
        Returns a list of matching TaskItems ids
        """
        if not self._git_path_is_valid(git_path):
            raise Exception(
                """
            git_path is invalid. Please make sure it has the 
            following format: "<repository_name>/<branch_name>"
            """
            )

        search_data = {
            "query": f"Select [System.Id] From WorkItems Where [{query_field}] Contains Words '{git_path}'"
        }

        rslt = requests.post(
            self.query_url,
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json",
            },
            auth=HTTPBasicAuth("", self.token),
            params={"api-version": QUERY_API_VERSION},
            data=json.dumps(search_data),
            timeout=10,
        )

        if rslt.status_code == 203:
            raise HTTPError("Token is not recognized")
        if rslt.status_code == 404:
            raise HTTPError(
                f"Organization or project is invalid: {self.dev_azure_org_project}")

        result = [item["id"] for item in rslt.json()["workItems"]]

        if len(result) > self.taskitem_query_limit:
            raise Exception(
                f"""
            Too much TaskItems have been found: {len(result)}, limit {self.taskitem_query_limit}. 
            """
            )
        return result

    def report_batch(
        self,
        query_field: str,
        git_path: str,
        field_name: str,
        value: str,
        operation: str,
    ) -> list:
        """
        This function performs an update of all the TaskItems that match the criterion:
        A field of TaskItem (query_field) must contain a name of a current repository and branch (git_path).
        Matching TaskItems are updated: a field specified in field_name parameter is being either overwritten
        with value if operation is "replace" or appended with value if operation is "add".
        Returns tasks ids upon successful updates.
        """

        task_ids = self._find_tasks(query_field, git_path)
        results = [
            self.report(task_id, field_name, value, operation) for task_id in task_ids
        ]

        return results

    def report(self, task_id: int, field_name: str, value: str, operation: str) -> int:
        """
        This function performs update of a single TaskItem at dev.azure.com
        Parameters: task_id, field_name (where to write to), value (what to write)
        and operation (add to existing field value or replace it).
        Returns task_id upon successful update.
        """
        data = [
            {
                "op": operation,
                "path": f"/fields/{field_name}",
                "value": value
                if operation != "add"
                else f"{self._read_taskitem_value(task_id,field_name)}<br>==========<br>{value}",
            }
        ]
        url = f"{self.workitem_url}{task_id}"

        rslt = requests.patch(
            url,
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json-patch+json",
            },
            auth=HTTPBasicAuth("", self.token),
            params={"api-version": WORKITEM_API_VERSION},
            data=json.dumps(data),
            timeout=10,
        )
        if rslt.status_code == 203:
            raise HTTPError("Token is not recognized")
        if rslt.status_code == 404:
            raise HTTPError(
                f"Organization or project is invalid: {self.dev_azure_org_project}")

        return task_id
